import { t } from 'i18next'
import React from 'react'
import VideoCard from '../components/Cards/VideoCard'
import Page from '../templates/Page'

function Videos() {
    return (
        <Page>
            <div className="container mx-auto px-8">
                <h2>{t('our_videos')}</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
                    <VideoCard title="Titile" img="https://db.cravingcamp.com/course_uploads/image_1640691757389.png" />
                    <VideoCard title="Titile" img="https://db.cravingcamp.com/course_uploads/image_1640691757389.png" />

                    <VideoCard title="Titile" img="https://db.cravingcamp.com/course_uploads/image_1640691757389.png" />

                    <VideoCard title="Titile" img="https://db.cravingcamp.com/course_uploads/image_1640691757389.png" />

                    <VideoCard title="Titile" img="https://db.cravingcamp.com/course_uploads/image_1640691757389.png" />

                </div>
            </div>
        </Page>
    )
}

export default Videos
