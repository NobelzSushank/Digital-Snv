import axios from 'axios';
import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { useHistory, useParams } from 'react-router-dom'
import Page from '../templates/Page';

import { useTranslation } from "react-i18next";

function Demographics() {

    const {user_id}=useParams();
    const [loading,setLoading]=useState(false);
  const history = useHistory();
  const [success,setSuccess]=useState(false);

  const { t } = useTranslation();


    const {
        register,
        handleSubmit,
        reset,
        formState: { errors },
      } = useForm();

      const onSubmit = async (data) => {
        try {
            await axios.post(`${process.env.REACT_APP_URL}/demographics`,{
              user_sub_id: `${user_id}`,
              gender: `${data.gender}`,
              age: `${data.age}`,
              district: `${data.district}`,
              registration_date:`${new Date().toDateString()}`,
            }).then(res=>{
              setLoading(false);
              history.push("/dashboard");
            })
          } catch (error) {
            if (error.response) {
              console.log(error.response.data)
              reset();
              setSuccess(false);
              setLoading(false);
            }
          }
    }
    
    return (
        <Page>
            <div className="container mx-auto px-4 px-8">
            <h3 className='text-center'>{t('additional_info')}</h3>
            <hr />
            <div className='flex justify-center p-2'>
             <form action='' onSubmit={handleSubmit(onSubmit)} className='my-4 lg:w-96'>
        <div className='flex flex-col space-y-3'>
          <label htmlFor='Age'>{t('age')}</label>
          <input
            type='text'
            name=''
            id='Age'
            className='input_txt rounded-md shadow-lg'
            {...register("age", { required: true })}
          />
          {errors.age && (
          <small className='text-red-500 mt-2 animate-bounce'>
            {t('age_is_required')}.
          </small>
        )}
          <label htmlFor='district'>{t('district')}</label>
          <input
            type='text'
            name=''
            id='district'
            className='input_txt rounded-md shadow-lg'
            {...register("district", { required: true })}

          />
          {errors.district && (
          <small className='text-red-500 mt-2 animate-bounce'>
            {t('district_is_required')}.
          </small>
        )}

          
          <label htmlFor='gender'>{t('लिङ्ग')}</label>
          <select {...register("gender",{ required: true })} id='gender' className='input_txt rounded-md shadow-lg'>
        <option value="">--{t('choose_gender')}--</option>

        <option value="female">{t('female')}</option>
        <option value="male">{t('male')}</option>
        <option value="other">{t('other')}</option>
      </select>
          

          {errors.gender && (
          <small className='text-red-500 mt-2 animate-bounce'>
            {t('gender_is_required')}
          </small>
        )}
        </div>
        <input
          type='submit'
          className='btn-primary cursor-pointer  mt-8 w-full rounded-md'
          value={loading? 'LOADING....' : 'SUBMIT & START LEARNING'}
        />
       
      </form>
        </div>
            </div>
        </Page>
    )
}

export default Demographics
