import { t } from 'i18next'
import React from 'react'
import Page from '../templates/Page'

import { useTranslation } from "react-i18next";

function Partners() {
    const { t } = useTranslation();
    return (
        <Page>
             <div className="container mx-auto px-4 lg:px-6">
                {t('partners')}
            </div>
        </Page>
    )
}

export default Partners
