import React from "react";
import Page from "../templates/Page";
import {IoIosPlay} from 'react-icons/io';
import homeImg from '../images/homeImg.png';
import { Link } from "react-router-dom";
import { AiFillPlayCircle } from "react-icons/ai";
import { useTranslation } from "react-i18next";

function Home() {
  const { t } = useTranslation();
  return (
    <Page>
      <div className='bg-primary-yellow'>
        <div className='container mx-auto px-4 lg:px-8'>
          <div className='lg:grid lg:grid-cols-2 lg:gap-8'>
            
            {/* left content side  */}
            <div className='py-10 lg:py-24'>
              <p className='font-medium text-gray-800 font-bold'>{t('digital_broadcast_makes_it_easy')}</p>
              <h1 className='my-8 font-bold text-5xl lg:text-6xl'>{t('all_the_tools_you_need_to_educate')}</h1>
              <p className='my-8 text-gray-500 text-lg '>

              {t('digital_broadcast_makes_it_easy_msg')}
                
              </p>

              <div className='my-4 flex items-center space-x-10 lg:space-x-6'>
                <Link to='/courses'>
                  <button className='p-3 lg:p-4 bg-primary lg:text-xl font-medium text-white rounded-md transition hover:opacity-80'>{t('get_started')}</button>
                </Link>
                <div className='flex items-center'><IoIosPlay className='bg-white p-4 text-primary rounded-full shadow-xl text-6xl cursor-pointer transition hover:opacity-80 mr-4 z-10' />
                <IoIosPlay className='bg-white p-4 text-primary rounded-full shadow-xl text-6xl cursor-pointer transition hover:opacity-80 mr-4 animate-ping absolute z-0' />
                    <p className='font-medium'>{t('watch_video')}</p>
                </div>
              </div>
            </div>

            {/* right img side  */}
            <div className='hidden lg:block p-10'>
              <h2>{t('watch_our_videos')}</h2>
              <div className="h-80 w-full bg-gray-800 rounded-md">

              <Link to='/videos'>
              <img src="https://db.cravingcamp.com/course_uploads/image_1640691757389.png" alt="home image" srcset="" className=" h-full object-cover p-2 transition opacity-30" />
              <div className="absolute top-80  text-white right-64 flex items-center space-x-4">
              <AiFillPlayCircle className="text-6xl" /> 
              <h1>
              <p>{t('watch_now')}</p>
              </h1>
              </div>
              </Link>

              </div>
            </div>

            
          </div>
        </div>
      </div>
    </Page>
  );
}

export default Home;
