import axios from "axios";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link, useHistory } from "react-router-dom";
import { useParams } from "react-router-dom";
import MasterLoading from "../components/LoadingSpinners/MasterLoading";
import Page from "../templates/Page";

import { useTranslation } from "react-i18next";

function StartCourse() {
  const { id } = useParams();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const user_ID = useSelector((state) => state.user.user_id);
  const history = useHistory();

  const { t } = useTranslation();

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        await axios
          .get(`${process.env.REACT_APP_URL}/course/subcontent/first/${id}`)
          .then((res) => {
            console.log(res)
            setData(res.data);
            setLoading(false);
          });
      } catch (error) {
        console.error(error);
      }
    };
    fetch();
  }, [id]);

  // handle course enrollment
  const handleEnrolledCourse = async () => {
    try {
      setLoading(true);
      await axios
        .post(`${process.env.REACT_APP_URL}/enrolled`, {
          user_id: user_ID,
          course_id: data[0].course_id,
          redirection_link: data[0].id,
        })
        .then((res) => {
          setLoading(false);
          history.push(`/0/${data[0].course_title}/${data[0].course_id}/subscribed/${data[0].id}`);
        });
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <Page>
      <div className='flex justify-center px-4 lg:px-0 py-10 bg-gray-300 lg:bg-gray-100'>
        <div className='card rounded-md p-4 lg:p-8 lg:w-1/3'>
          {loading && <MasterLoading />}
          {data.map((item) => (
            <div>
              <img
                src={item.image}
                alt={item.course_title}
                srcset=''
                className='h-44 w-full object-cover'
              />
              <h3>{item.course_title}</h3>
              <div className='my-2 text-gray-600'>{item.short_description}</div>

              <button
                className='btn-primary my-4 rounded w-full'
                onClick={handleEnrolledCourse}
              >
                {t('start_now')}
              </button>
            </div>
          ))}
        </div>
      </div>
    </Page>
  );
}

export default StartCourse;
