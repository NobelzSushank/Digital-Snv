import React from 'react'

import { useTranslation } from "react-i18next";

function ErrorPage() {
    const { t } = useTranslation();

    return (
        <div>
            <h1>{t('you_are_not_allowed_to_visit_this')}</h1>
        </div>
    )
}

export default ErrorPage
