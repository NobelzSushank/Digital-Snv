import { t } from 'i18next'
import React from 'react'
import { Link } from 'react-router-dom'
import loginImg from '../../images/login.svg'

import { useTranslation } from "react-i18next";

function LoginOrRegister(props) {
    const { t } = useTranslation();
    return (
        <div className='bg-gray-100 lg:min-h-screen'>
            <div className="container mx-auto lg:px-8 px-4">
                <div className="lg:grid grid-cols-12 lg:gap-4">
                    <div className="hidden lg:block lg:col-span-7">
                        <Link to='/'>
                        <p className='font-bold text-primary mt-16 mx-4'>
                            {t('digital_broadcast')}
                        </p>
                        </Link>
                        <h1 className="mt-8 mx-4">
                        {t('discover_best_classes_for')} <br /> <span className='text-blue-500'>{t('the_best_learning')}
                            </span> 
                        </h1>
                        <div className="p-16">
                        <img src={loginImg} alt="login image" srcset="" className='w-3/4' />

                        </div>
                    </div>
                    <div className="lg:col-span-4 py-4">
                        <div className="bg-white p-10 rounded shadow-xl">
                            {props.children}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default LoginOrRegister
