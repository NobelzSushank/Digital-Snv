import { t } from 'i18next'
import React from 'react'
import AvgReview from './TabUtils/AvgReview'

import { useTranslation } from "react-i18next";

function TabReviews() {
    const { t } = useTranslation();
    return (
        <div>
            <h1>{t('reviews')}</h1>

            <AvgReview />
        </div>
    )
}

export default TabReviews
