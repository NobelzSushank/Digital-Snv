import axios from "axios";
import React from "react";
import { useState } from "react";
import { AiFillCloseCircle } from "react-icons/ai";
import {FaCheckCircle} from 'react-icons/fa'
import { Link, useParams } from "react-router-dom";

function ContentTitles({ no, title, src, time, checked,id,course_id }) {
  const {enrolled_id}=useParams();
  const subcontentId=useParams().id;
  const [loading,setLoading]=useState(false);
  // This function will scroll the window to the top 
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth' // for smoothly scrolling
    });
  };

  const handleProgress=async()=>{
    try {
      setLoading(true);
      await axios.post(`${process.env.REACT_APP_URL}/progress`,{
        enrolled_id:enrolled_id,
        sub_section_id:subcontentId,
        checked:"true"
      }).then(res=>{
        console.log(res);
        setLoading(false);
      })
    } catch (error) {
      console.error(error)
    }
  }
  return (
    <div className={`flex px-2 py-2 my-2 ${parseInt(subcontentId)===id && 'bg-gray-300'}`}>
      {!checked  ? (
        <AiFillCloseCircle className="text-gray-600" />
      ) : (
       <FaCheckCircle className="text-green-500" />
      )}
        
      <Link to={`/${enrolled_id}/${title}/${course_id}/subscribed/${id}`} onClick={scrollToTop} >
      <div className='-mt-1 ml-2'>
        <p>
          {no} {title}
        </p>
        <p className='text-sm'>{time}</p>
        {parseInt(subcontentId)===id&&

        !checked && 
          <p className="font-medium my-2 text-gray-800" onClick={handleProgress}>
            <u>
            {loading ? 'LOADING...' : 'Mark as Finished'}
            </u>
          </p>
          
        }
      </div>
      </Link>
    </div>
    
  );
}

export default ContentTitles;
