import React from 'react'
import { AiOutlineFieldTime } from 'react-icons/ai'
import { BsPersonFill } from 'react-icons/bs'
import { RiMoneyPoundCircleFill } from 'react-icons/ri'

import { useTranslation } from "react-i18next";

function CoursesInfoIconCard({time}) {
    const { t } = useTranslation();
    return (
       <div className="my-12 lg:flex lg:items-center lg:justify-between">
            <div className="flex text-xl space-x-5 my-7">
                                <AiOutlineFieldTime className='text-2xl lg:mt-1' /> 
                                <div>
                                <p className='font-bold'>{t('esitmated_time')}</p>
                                <p className='text-sm font-medium text-gray-600'>{time}</p>
                                </div>
                            </div>

                            <div className="flex text-xl space-x-5 my-7">
                                <BsPersonFill className='text-2xl lg:mt-1' /> 
                                <div>
                                <p className='font-bold'>{t('personal_perference')}</p>
                                <p className='text-sm font-medium text-gray-600'>{t('progress_at_your_own_speed')}</p>
                                </div>
                            </div>

                            <div className="flex text-xl space-x-5 my-7">
                                <RiMoneyPoundCircleFill className='text-2xl lg:mt-1' /> 
                                <div>
                                <p className='font-bold'>{t('free')}</p>
                                <p className='text-sm font-medium text-gray-600'>{t('learn_for_free')}</p>
                                </div>
                            </div>

       </div>
    )
}

export default CoursesInfoIconCard
