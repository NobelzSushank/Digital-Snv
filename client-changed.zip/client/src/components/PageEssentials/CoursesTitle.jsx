import { t } from 'i18next'
import React from 'react'
import { useTranslation } from "react-i18next";

function CoursesTitle({course}) {
    const { t } = useTranslation();
    return (
        <div className='my-4'>
            <h1 className="my-3">
                {course} {t('courses')}
            </h1>
        </div>
    )
}

export default CoursesTitle
