import React, { useEffect } from 'react'
import { Circle } from 'rc-progress';
import { useParams } from 'react-router-dom';
import { useState } from 'react';
import axios from 'axios';

import { useTranslation } from "react-i18next";

function TabProgress() {
    const { t } = useTranslation();

    const {enrolled_id,course_id}=useParams();
    const [totalData,setTotalData]=useState('');
    const [completedData,setCompletedData]=useState('');

    useEffect(() => {
      const fetch=async()=>{
          const completed= axios.get(`${process.env.REACT_APP_URL}/progress/user/${enrolled_id}`);
          const total= axios.get(`${process.env.REACT_APP_URL}/statistics/allSubContent/${course_id}`);

          await axios.all([completed,total]).then(axios.spread(function(res1,res2){
              setCompletedData(res1.data.length);
              setTotalData(res2.data[0].no);
          }))
          
         
      }
      fetch();
    }, [enrolled_id,course_id])
    return (
        <div>
           <h1>{t('my_progress')}</h1>
           <div className="my-4">
               <p>{t('total_completed_course')} : <span><b>{completedData}</b></span> out of <span><b>{totalData} </b></span></p>
           </div>
           <div className="w-44">
                <Circle percent="50" strokeWidth="4" strokeColor="#006699" className='relative' /> 
                <p className="text-3xl font-medium absolute -mt-28 ml-16">
                    {Math.round(100/totalData*completedData)} %
                </p> 
           </div>
        </div>
    )
}

export default TabProgress
